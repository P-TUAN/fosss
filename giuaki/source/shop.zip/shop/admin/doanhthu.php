<?php 
  $tongtienhientai = 0;
  $tongtiendutinh = 0;
  $tongtiengiam = 0;
  if (isset($_COOKIE["user"])) {
      $user = $_COOKIE["user"];
      foreach (selectAll("SELECT * FROM taikhoan WHERE taikhoan='$user'") as $row) {
          $permission = $row['phanquyen'];
      }
      if ($permission==1) {
        foreach (selectAll("SELECT * FROM donhang WHERE status =4") as $item) {
          $tongtiengiam += $item['tongtien'];
        }
        foreach (selectAll("SELECT * FROM donhang WHERE status =3") as $item) {
          $tongtienhientai += $item['tongtien'];
        }
        foreach (selectAll("SELECT * FROM donhang WHERE status =3 or status =2 or status =1") as $item2) {
            $tongtiendutinh += $item2['tongtien'];
        }
        
?>

<!-- partial -->
<div class="main-panel">
          <div class="content-wrapper">
            <div class="row">

              <div class="col-sm-4 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h5 class="addfont">Tổng Doanh Thu Hiện Tại</h5>
                    <div class="row">
                      <div class="col-8 col-sm-12 col-xl-8 my-auto">
                        <div class="d-flex d-sm-block d-md-flex align-items-center">
                          <h2 class="mb-0"><?= number_format($tongtienhientai)?>đ</h2>
                        </div>
                      </div>
                      <div class="col-4 col-sm-12 col-xl-4 text-center text-xl-right">
                        <i class="icon-lg mdi mdi-monitor text-success ml-auto"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              

              
            </div>
            
          </div>
          <script src="./js/search.js?v=<?php echo time()?>"></script>
            <?php
        }
    }

 ?>