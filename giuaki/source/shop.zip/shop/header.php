<section><div class="breadcrumb "><img src="img/logosss.png" class="img-fluid" alt=""></div></section><?php 
    if (isset($_GET["checkout"])) {
        setcookie("user", null, -1, '/');
        header('location:index.php');
    }
    ?>
    
    <!--::header part start::-->
    <style>section.head {
    background-color: #0a804a73
   ;}
    .dropdown .dropdown-menu .dropdown-item {
    font-size: 14px;
    padding: 8px 20px !important;
    color: #fff !important;
    background-color: #0a804a;
    text-transform: capitalize;
}
.dropdown .dropdown-menu {
    transition: all 0.5s;
    overflow: hidden;
    transform-origin: top center;
    transform: scale(1, 0);
    display: block;
    border: 0px solid transparent;
    background-color: #0a804a;
}
.content-wrapper {
    background: #bababa;
    padding: 1.875rem 1.75rem;
    width: 100%;
    -webkit-flex-grow: 1;
    flex-grow: 1;
}

</style>
    <section class="head">
    

        <div class="container">
            <div class="row ccc">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                       
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="menu_icon"><i class="fas fa-bars"></i></span>
                        </button>

                        <div class="collapse navbar-collapse main-menu-item" id="navbarSupportedContent">
                            <ul class="navbar-nav">
                                


                                <li class="nav-item">
                                    <a class="nav-link" href="sanpham.php">Trang chủ</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="lichsu.php">Lịch sử</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="lienhe.php">Liên hệ</a>
                                </li>

                                <?php 
                                    if (isset($_COOKIE["user"])) {
                                        $taikhoan = $_COOKIE["user"];
                                        foreach (selectAll("SELECT * FROM taikhoan WHERE taikhoan='$taikhoan'") as $item) {
                                            $ten = $item['hoten'];
                                            $anh = $item['anh'];
                                            $phanquyen = $item['phanquyen'];
                                        }
                                ?>
                                
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="" id="navbarDropdown_3" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Chào <?= $ten ?>
                                          
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="navbarDropdown_2">
                                            <?php 
                                                if ($phanquyen==1) {
                                            ?>
                                                <a class="dropdown-item" href="admin">Trang quản trị</a>
                                            <?php
                                            }
                                            ?>

                                            <a class="dropdown-item" href="thongtintk.php"> thông tin tài khoản</a>
                                            <a class="dropdown-item" href="?checkout">đăng xuất</a>
                                            
                                        </div>
                                    </li>
                                <?php
                                    }
                                    else{
                                ?>
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="" id="navbarDropdown_3" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            tài khoản
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="navbarDropdown_2">
                                            <a class="dropdown-item" href="dangky.php"> đăng ký</a>
                                            <a class="dropdown-item" href="dangnhap.php">đăng nhập</a>
                                        </div>
                                    </li>
                                <?php
                                    }
                                ?>
                            </ul>
                        </div>
                        <div class="hearer_icon d-flex">
                            <a id="search_1" href="javascript:void(0)" style="cursor: pointer; margin: right -20px;"><i class="ti-search" style="font-size:20px"></i></a>

                            <div >
                                <a class="" href="gio.php" id="navbarDropdown3" role="button" > <!-- data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" -->
                                    <i class="fa fa-cart-plus"style="font-size:20px"></i>
                                    <?php 
                                        if (isset($_COOKIE["user"])) {
                                            $taikhoan = $_COOKIE["user"];
                                            foreach (selectAll("SELECT * FROM taikhoan WHERE taikhoan ='$taikhoan'") as $item) {
                                                $id_nguoidung = $item['id'];
                                            }
                                            if (rowCount("SELECT * FROM donhang WHERE id_taikhoan=$id_nguoidung && status=0")>0) {
                                                foreach (selectAll("SELECT * FROM donhang WHERE id_taikhoan=$id_nguoidung && status=0") as $items) {
                                                    $id_donhang = $items['id'];
                                                }
                                                if(rowCount("SELECT * FROM ctdonhang WHERE id_donhang=$id_donhang")>0){
                                                ?>
                                                <span class='badge badge-danger' style='vertical-align: top; margin:-10px 0px 0px -10px; font-size:10px'><?= rowCount("SELECT * FROM ctdonhang WHERE id_donhang=$id_donhang") ?></span>
                                                <?php 
                                                } else{
                                                ?>
                                                    <span></span>
                                                <?php
                                                }
                                                ?>
                                                <?php
                                            }
                                        }
                                    ?>
                                </a>
                            

                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <div class="search_input" id="search_input_box">
            <div class="container ">
                <form class="d-flex justify-content-between search-inner" action="sanpham.php" method="GET" autocomplete="off">
                    <input type="text" class="form-control" name="tim" placeholder="Nhập tên sản phẩm cần tìm">
                    <button type="submit" class="btn"></button>
                    <span class="ti-close" id="close_search" title="Close Search"></span>
                </form>
            </div>
        </div>
    </section>
    <!-- Header part end--