<?php 
    
    ?>
    <footer class="footer_part" style=" margin-top: 10px; padding: 20px; background-color: #F1F1F1; background-clip: padding;">
        <div class="container">
            <div class="row justify-content-around">
                <div class="col-sm-6 col-lg-3">
                    <div class="single_footer_part">
                        <h4>Thông Tin SV Thực Hiện</h4>
                        <ul class="list-unstyled">
                            <li><a href="">Họ và tên: Phạm Minh Tuấn</a></li>
                            <li><a href="">Lớp: 09-CNPM3</a></li>
                            <li><a href="">MSSV: 0950080115</a></li>
                            <li><a href="">Địa Chỉ: 247 LLQ p3 q11</a></li>
                        </ul>
                    </div>
                </div>
                
                
        </div>
    </footer>
